package spring.course.controller;

public class NotiTranController {

}
