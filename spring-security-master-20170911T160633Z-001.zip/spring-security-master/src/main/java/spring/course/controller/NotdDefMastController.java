package spring.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import spring.course.model.Employee;
import spring.course.model.NotdDefMast;
import spring.course.service.NotdDefMastService;

@RestController
public class NotdDefMastController {

	@Autowired
	NotdDefMastService notdDefMastService;

	@RequestMapping(value = "/notddefmast/", method = RequestMethod.GET)
	public ResponseEntity<List<NotdDefMast>> getAllNotdDefMast() {
		List<NotdDefMast> employees = notdDefMastService.findAllNotdDefMast();
		if (null == employees || employees.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<NotdDefMast>>(employees, HttpStatus.OK);
	}
	

	@RequestMapping(value = "/notddefmast/", method = RequestMethod.POST)
	public ResponseEntity<?> createNotdDefMast(@RequestBody NotdDefMast notdDefMast, UriComponentsBuilder ucBuilder) {

		notdDefMastService.saveNotdDefMast(notdDefMast);

		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<String>("ddf", HttpStatus.CREATED);
	}
}
