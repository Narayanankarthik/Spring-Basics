package spring.course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import spring.course.configuration.JpaConfiguration;
import spring.course.repositories.UserRepository;
import spring.course.service.UserService;

@Import(JpaConfiguration.class)
@SpringBootApplication(scanBasePackages = { "spring.course" })
public class MainSpringBootApp {

	public static void main(String[] args) {
		SpringApplication.run(MainSpringBootApp.class, args);
	}

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	public void authenticationManager(AuthenticationManagerBuilder builder, UserRepository repository,
			UserService service) throws Exception {
		builder.userDetailsService(userDetailsService(repository)).passwordEncoder(passwordEncoder);
	}

	private UserDetailsService userDetailsService(final UserRepository repository) {
		return username -> repository.findByUsername(username);
	}
}
