package spring.course.service;

import java.util.List;

import spring.course.model.NotdDefMast;

public interface NotdDefMastService {

	List<NotdDefMast> findAllNotdDefMast();

	void saveNotdDefMast(NotdDefMast notdDefMast);
}
