package spring.course.service;

import java.util.List;

import spring.course.model.User;

public interface UserService {

	User findById(Long id);

	User findByUserName(String userName);

	void saveUser(User user);

	void updateUser(User user);

	void deleteById(Long id);
	
	List<User> findAllUsers();

	void deleteAllUsers();

	public boolean isUserExist(User user);

}
