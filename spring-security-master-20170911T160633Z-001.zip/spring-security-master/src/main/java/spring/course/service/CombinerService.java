package spring.course.service;

import spring.course.model.Employee;

public interface CombinerService {

	Employee createEmployeeAccount(Employee employee);
}