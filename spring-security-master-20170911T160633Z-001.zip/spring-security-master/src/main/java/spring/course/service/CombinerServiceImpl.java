package spring.course.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import spring.course.model.Employee;
import spring.course.model.Role;
import spring.course.model.User;

@Service("combinerService")
@Transactional
public class CombinerServiceImpl implements CombinerService {

	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private UserService userService;

	@Override
	public Employee createEmployeeAccount(Employee employee) {
		User user = new User();
		user.setUsername(employee.getEmail());
		user.setPassword("password123");
		user.setEnabled(true);
		List<Role> roles = new ArrayList<>();
		roles.add(new Role(1l, "ADMIN"));
		user.setRoles(roles);

		userService.saveUser(user);
		employeeService.saveEmployee(employee);
		return employee;
	}

}
