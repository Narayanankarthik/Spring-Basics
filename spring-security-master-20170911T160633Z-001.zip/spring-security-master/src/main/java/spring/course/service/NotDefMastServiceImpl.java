package spring.course.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.course.model.NotdDefMast;
import spring.course.repositories.NotdDefMastRepository;

@Service ("notdDefMastService")
public class  NotDefMastServiceImpl implements NotdDefMastService {
	
	@Autowired
	NotdDefMastRepository notdDefMastRepository;

	@Override
	public List<NotdDefMast> findAllNotdDefMast() {
	
		return notdDefMastRepository.findAll();
	}

	@Override
	public void saveNotdDefMast(NotdDefMast notdDefMast) {
		notdDefMastRepository.save(notdDefMast);
		
	}

}
