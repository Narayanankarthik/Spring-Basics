package spring.course.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the stat database table.
 * 
 */
@Entity
@NamedQuery(name="Stat.findAll", query="SELECT s FROM Stat s")
public class Stat implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="STAT_ID")
	private int statId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="APR_TIMESMP")
	private Date aprTimesmp;

	@Column(name="APR_USER_ID")
	private String aprUserId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CRE_TIMESMP")
	private Date creTimesmp;

	@Column(name="CRE_USER_ID")
	private String creUserId;

	@Column(name="STAT_CD")
	private String statCd;

	@Column(name="STAT_DET")
	private String statDet;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPD_TIMESMP")
	private Date updTimesmp;

	@Column(name="UPD_USER_ID")
	private String updUserId;

	public Stat() {
	}

	public int getStatId() {
		return this.statId;
	}

	public void setStatId(int statId) {
		this.statId = statId;
	}

	public Date getAprTimesmp() {
		return this.aprTimesmp;
	}

	public void setAprTimesmp(Date aprTimesmp) {
		this.aprTimesmp = aprTimesmp;
	}

	public String getAprUserId() {
		return this.aprUserId;
	}

	public void setAprUserId(String aprUserId) {
		this.aprUserId = aprUserId;
	}

	public Date getCreTimesmp() {
		return this.creTimesmp;
	}

	public void setCreTimesmp(Date creTimesmp) {
		this.creTimesmp = creTimesmp;
	}

	public String getCreUserId() {
		return this.creUserId;
	}

	public void setCreUserId(String creUserId) {
		this.creUserId = creUserId;
	}

	public String getStatCd() {
		return this.statCd;
	}

	public void setStatCd(String statCd) {
		this.statCd = statCd;
	}

	public String getStatDet() {
		return this.statDet;
	}

	public void setStatDet(String statDet) {
		this.statDet = statDet;
	}

	public Date getUpdTimesmp() {
		return this.updTimesmp;
	}

	public void setUpdTimesmp(Date updTimesmp) {
		this.updTimesmp = updTimesmp;
	}

	public String getUpdUserId() {
		return this.updUserId;
	}

	public void setUpdUserId(String updUserId) {
		this.updUserId = updUserId;
	}

}