package spring.course.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the noti_temp_mast database table.
 * 
 */
@Entity
@Table(name="noti_temp_mast")
@NamedQuery(name="NotiTempMast.findAll", query="SELECT n FROM NotiTempMast n")
public class NotiTempMast implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="NOTI_TEMP_ID")
	private int notiTempId;

	@Column(name="CONT_DESC")
	private String contDesc;

	@Column(name="CONT_TY")
	private String contTy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_AT")
	private Date createdAt;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="STAT_CD")
	private String statCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATED_AT")
	private Date updatedAt;

	@Column(name="UPDATED_BY")
	private String updatedBy;

	@Column(name="VER_NR")
	private int verNr;


	public NotiTempMast() {
	}

	public int getNotiTempId() {
		return this.notiTempId;
	}

	public void setNotiTempId(int notiTempId) {
		this.notiTempId = notiTempId;
	}

	public String getContDesc() {
		return this.contDesc;
	}

	public void setContDesc(String contDesc) {
		this.contDesc = contDesc;
	}

	public String getContTy() {
		return this.contTy;
	}

	public void setContTy(String contTy) {
		this.contTy = contTy;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getStatCd() {
		return this.statCd;
	}

	public void setStatCd(String statCd) {
		this.statCd = statCd;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public int getVerNr() {
		return this.verNr;
	}

	public void setVerNr(int verNr) {
		this.verNr = verNr;
	}



}