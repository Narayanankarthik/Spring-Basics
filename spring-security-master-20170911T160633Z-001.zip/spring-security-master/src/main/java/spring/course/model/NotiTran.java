package spring.course.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the noti_trans database table.
 * 
 */
@Entity
@Table(name="noti_trans")
@NamedQuery(name="NotiTran.findAll", query="SELECT n FROM NotiTran n")
public class NotiTran implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="NOTI_TRANS_ID")
	private int notiTransId;

	@Column(name="ADD_DET")
	private String addDet;

	@Column(name="COM_ID")
	private int comId;

	@Column(name="COM_TY")
	private String comTy;

	@Column(name="CON_ID")
	private int conId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_AT")
	private Date createdAt;

	@Column(name="FUNC_ID")
	private int funcId;

	@Column(name="NOT_TYPE")
	private String notType;

	private String NOTI_TRANS_DETAIlS;

	private String param;

	@Column(name="RETRY_CNT")
	private int retryCnt;

	@Column(name="STAT_CD")
	private String statCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATED_AT")
	private Date updatedAt;

	//bi-directional many-to-one association to NoscSche
	@ManyToOne
	@JoinColumn(name="NOSC_SCHE_ID")
	private NoscSche noscSche;

	public NotiTran() {
	}

	public int getNotiTransId() {
		return this.notiTransId;
	}

	public void setNotiTransId(int notiTransId) {
		this.notiTransId = notiTransId;
	}

	public String getAddDet() {
		return this.addDet;
	}

	public void setAddDet(String addDet) {
		this.addDet = addDet;
	}

	public int getComId() {
		return this.comId;
	}

	public void setComId(int comId) {
		this.comId = comId;
	}

	public String getComTy() {
		return this.comTy;
	}

	public void setComTy(String comTy) {
		this.comTy = comTy;
	}

	public int getConId() {
		return this.conId;
	}

	public void setConId(int conId) {
		this.conId = conId;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public int getFuncId() {
		return this.funcId;
	}

	public void setFuncId(int funcId) {
		this.funcId = funcId;
	}

	public String getNotType() {
		return this.notType;
	}

	public void setNotType(String notType) {
		this.notType = notType;
	}

	public String getNOTI_TRANS_DETAIlS() {
		return this.NOTI_TRANS_DETAIlS;
	}

	public void setNOTI_TRANS_DETAIlS(String NOTI_TRANS_DETAIlS) {
		this.NOTI_TRANS_DETAIlS = NOTI_TRANS_DETAIlS;
	}

	public String getParam() {
		return this.param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public int getRetryCnt() {
		return this.retryCnt;
	}

	public void setRetryCnt(int retryCnt) {
		this.retryCnt = retryCnt;
	}

	public String getStatCd() {
		return this.statCd;
	}

	public void setStatCd(String statCd) {
		this.statCd = statCd;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public NoscSche getNoscSche() {
		return this.noscSche;
	}

	public void setNoscSche(NoscSche noscSche) {
		this.noscSche = noscSche;
	}

}