package spring.course.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the notd_def_mast database table.
 * 
 */
@Entity
@Table(name="notd_def_mast")
@NamedQuery(name="NotdDefMast.findAll", query="SELECT n FROM NotdDefMast n")
public class NotdDefMast implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="NOTD_DEF_ID")
	private int notdDefId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_AT")
	private Date createdAt;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="NO_RETRY")
	private int noRetry;

	@Column(name="NOTI_TY_CD")
	private String notiTyCd;

	@Column(name="STAT_CD")
	private String statCd;

	@Column(name="SYS_CD")
	private String sysCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATED_AT")
	private Date updatedAt;

	@Column(name="UPDATED_BY")
	private String updatedBy;


	public NotdDefMast() {
	}

	public int getNotdDefId() {
		return this.notdDefId;
	}

	public void setNotdDefId(int notdDefId) {
		this.notdDefId = notdDefId;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public int getNoRetry() {
		return this.noRetry;
	}

	public void setNoRetry(int noRetry) {
		this.noRetry = noRetry;
	}

	public String getNotiTyCd() {
		return this.notiTyCd;
	}

	public void setNotiTyCd(String notiTyCd) {
		this.notiTyCd = notiTyCd;
	}

	public String getStatCd() {
		return this.statCd;
	}

	public void setStatCd(String statCd) {
		this.statCd = statCd;
	}

	public String getSysCd() {
		return this.sysCd;
	}

	public void setSysCd(String sysCd) {
		this.sysCd = sysCd;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



}