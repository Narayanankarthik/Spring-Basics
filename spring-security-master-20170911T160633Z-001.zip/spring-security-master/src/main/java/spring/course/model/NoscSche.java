package spring.course.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the nosc_sche database table.
 * 
 */
@Entity
@Table(name="nosc_sche")
@NamedQuery(name="NoscSche.findAll", query="SELECT n FROM NoscSche n")
public class NoscSche implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="NOSC_SCHE_ID")
	private Long noscScheId;

	@Column(name="ADD_DTL")
	private String addDtl;

	@Column(name="CON_SRC_DTL")
	private String conSrcDtl;

	@Column(name="CON_SRC_TY")
	private String conSrcTy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_AT")
	private Date createdAt;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="PAR_NOT_SCH_ID")
	private int parNotSchId;

	@Column(name="STAT_CD")
	private String statCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATED_AT")
	private Date updatedAt;

	@Column(name="UPDATED_BY")
	private String updatedBy;

	//bi-directional many-to-one association to ScheDefMast
	@ManyToOne
	@JoinColumn(name="SCHE_ID")
	private ScheDefMast scheDefMast;


	//bi-directional many-to-one association to NotiTran
	@OneToMany(mappedBy="noscSche")
	private List<NotiTran> notiTrans;

	public NoscSche() {
	}



	public Long getNoscScheId() {
		return noscScheId;
	}



	public void setNoscScheId(Long noscScheId) {
		this.noscScheId = noscScheId;
	}



	public String getAddDtl() {
		return this.addDtl;
	}

	public void setAddDtl(String addDtl) {
		this.addDtl = addDtl;
	}

	public String getConSrcDtl() {
		return this.conSrcDtl;
	}

	public void setConSrcDtl(String conSrcDtl) {
		this.conSrcDtl = conSrcDtl;
	}

	public String getConSrcTy() {
		return this.conSrcTy;
	}

	public void setConSrcTy(String conSrcTy) {
		this.conSrcTy = conSrcTy;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public int getParNotSchId() {
		return this.parNotSchId;
	}

	public void setParNotSchId(int parNotSchId) {
		this.parNotSchId = parNotSchId;
	}

	public String getStatCd() {
		return this.statCd;
	}

	public void setStatCd(String statCd) {
		this.statCd = statCd;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public ScheDefMast getScheDefMast() {
		return this.scheDefMast;
	}

	public void setScheDefMast(ScheDefMast scheDefMast) {
		this.scheDefMast = scheDefMast;
	}


	public List<NotiTran> getNotiTrans() {
		return this.notiTrans;
	}

	public void setNotiTrans(List<NotiTran> notiTrans) {
		this.notiTrans = notiTrans;
	}

	public NotiTran addNotiTran(NotiTran notiTran) {
		getNotiTrans().add(notiTran);
		notiTran.setNoscSche(this);

		return notiTran;
	}

	public NotiTran removeNotiTran(NotiTran notiTran) {
		getNotiTrans().remove(notiTran);
		notiTran.setNoscSche(null);

		return notiTran;
	}

}