package spring.course.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the sche_def_mast database table.
 * 
 */
@Entity
@Table(name="sche_def_mast")
@NamedQuery(name="ScheDefMast.findAll", query="SELECT s FROM ScheDefMast s")
public class ScheDefMast implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SCHE_ID")
	private int scheId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_AT")
	private Date createdAt;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="DAY_CD")
	private String dayCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="END_DT")
	private Date endDt;

	@Column(name="INVO_DTLS")
	private String invoDtls;

	@Column(name="INVO_TY")
	private String invoTy;

	private String occr;

	@Column(name="PAR_SCHE_ID")
	private int parScheId;

	@Column(name="RECUR_PAT")
	private String recurPat;

	@Column(name="STAT_CD")
	private String statCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="STRT_DT")
	private Date strtDt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATED_AT")
	private Date updatedAt;

	@Column(name="UPDATED_BY")
	private String updatedBy;


	public ScheDefMast() {
	}

	public int getScheId() {
		return this.scheId;
	}

	public void setScheId(int scheId) {
		this.scheId = scheId;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getDayCd() {
		return this.dayCd;
	}

	public void setDayCd(String dayCd) {
		this.dayCd = dayCd;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public String getInvoDtls() {
		return this.invoDtls;
	}

	public void setInvoDtls(String invoDtls) {
		this.invoDtls = invoDtls;
	}

	public String getInvoTy() {
		return this.invoTy;
	}

	public void setInvoTy(String invoTy) {
		this.invoTy = invoTy;
	}

	public String getOccr() {
		return this.occr;
	}

	public void setOccr(String occr) {
		this.occr = occr;
	}

	public int getParScheId() {
		return this.parScheId;
	}

	public void setParScheId(int parScheId) {
		this.parScheId = parScheId;
	}

	public String getRecurPat() {
		return this.recurPat;
	}

	public void setRecurPat(String recurPat) {
		this.recurPat = recurPat;
	}

	public String getStatCd() {
		return this.statCd;
	}

	public void setStatCd(String statCd) {
		this.statCd = statCd;
	}

	public Date getStrtDt() {
		return this.strtDt;
	}

	public void setStrtDt(Date strtDt) {
		this.strtDt = strtDt;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



}