package spring.course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ROLE_MASTER")
public class Role {

	@Id
	@GeneratedValue
	@Column(name = "ROLE_ID", nullable = false, updatable = false)
	private Long id;
	@Column(name = "ROLE_CODE", nullable = false, updatable = false)
	String code;

	Role() {
	}

	public Role(Long id, String code) {
		this.id = id;
		this.code = code;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "Role [id=" + id + ", code=" + code + "]";
	}

}
