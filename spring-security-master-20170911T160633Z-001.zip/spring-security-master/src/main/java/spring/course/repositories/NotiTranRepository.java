package spring.course.repositories;

public interface NotiTranRepository {

}
