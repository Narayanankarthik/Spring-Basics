package spring.course.repositories;

public interface ScheDefMastRepository {

}
