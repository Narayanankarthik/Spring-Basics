package spring.course.repositories;

public interface StatRepository {

}
